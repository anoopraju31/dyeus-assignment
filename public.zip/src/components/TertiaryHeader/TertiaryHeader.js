import './TertiaryHeader.css'

const TertiaryHeader = ({title}) => {
    return (
        <div className='tertiaryHeader'>
            {title}
        </div>
    )
}

export default TertiaryHeader