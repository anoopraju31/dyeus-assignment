import './Quote.css'

const Quote = () => {
  return (
    <div className='quote'>
        <h1> With Diana, you’re in control of your health, your every day, and your story. </h1>
    </div>
  )
}

export default Quote